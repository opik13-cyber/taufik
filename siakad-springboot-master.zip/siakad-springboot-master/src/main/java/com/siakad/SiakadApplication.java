package com.siakad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiakadApplication {
    public static void main(String[] args) {
        SpringApplication.run(SiakadApplication.class, args);
    }
}