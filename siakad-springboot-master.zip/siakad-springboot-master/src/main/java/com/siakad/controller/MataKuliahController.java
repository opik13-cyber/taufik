package com.siakad.controller;

import com.siakad.dao.MataKuliahDAO;
import com.siakad.model.MataKuliah;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping("/api/matakuliah")
public class MataKuliahController {

    @Autowired
    private MataKuliahDAO matakuliahDAO;

    @GetMapping
    public List<MataKuliah> getAllMatakuliah() {
        return matakuliahDAO.findAll();
    }

    @GetMapping("/{id}")
    public MataKuliah getMatakuliahById(@PathVariable Integer id) {
        try {
            return matakuliahDAO.findById(id);
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Matakuliah tidak ditemukan");
        }
    }

    @PostMapping
    public void createMatakuliah(@RequestBody MataKuliah matakuliah) {
        matakuliahDAO.save(matakuliah);
    }

    @PutMapping("/{id}")
    public void updateMatakuliah(@PathVariable Integer id, @RequestBody MataKuliah matakuliah) {
        matakuliah.setMatkulId(id);
        matakuliahDAO.update(matakuliah);
    }

    @DeleteMapping("/{id}")
    public void deleteMatakuliah(@PathVariable Integer id) {
        matakuliahDAO.delete(id);
    }
}
