package com.siakad.controller;

import com.siakad.dao.FakultasDAO;
import com.siakad.model.Fakultas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping("/api/fakultas")
public class FakultasController {

    @Autowired
    private FakultasDAO fakultasDAO;

    @GetMapping
    public List<Fakultas> getAllFakultas() {
        return fakultasDAO.findAll();
    }

    @GetMapping("/{id}")
    public Fakultas getFakultasById(@PathVariable Integer id) {
        try {
            return fakultasDAO.findById(id);
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Fakultas tidak ditemukan");
        }
    }

    @PostMapping
    public void createFakultas(@RequestBody Fakultas fakultas) {
        fakultasDAO.save(fakultas);
    }

    @PutMapping("/{id}")
    public void updateFakultas(@PathVariable Integer id, @RequestBody Fakultas fakultas) {
        fakultas.setFakultasId(id);
        fakultasDAO.update(fakultas);
    }

    @DeleteMapping("/{id}")
    public void deleteFakultas(@PathVariable Integer id) {
        fakultasDAO.delete(id);
    }
}
