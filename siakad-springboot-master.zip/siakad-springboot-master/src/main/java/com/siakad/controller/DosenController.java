package com.siakad.controller;

import com.siakad.dao.DosenDAO;
import com.siakad.model.Dosen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/dosen")
public class DosenController {

    @Autowired
    private DosenDAO dosenDAO;

    // Get all dosen
    @GetMapping
    public List<Dosen> getAllDosen() {
        return dosenDAO.findAll();
    }

    // Get dosen by id
    @GetMapping("/{id}")
    public Dosen getDosenById(@PathVariable Integer id) {
        try {
            return dosenDAO.findById(id);
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Dosen tidak ditemukan");
        }
    }

    // Create dosen
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Dosen createDosen(@RequestBody Dosen dosen) {
        if (dosen.getNamaDosen() == null || dosen.getNamaDosen().trim().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Nama Dosen tidak boleh kosong.");
        }
        dosenDAO.save(dosen);
        return dosen;
    }

    // Update dosen
    @PutMapping("/{id}")
    public Dosen updateDosen(@PathVariable Integer id, @RequestBody Dosen dosen) {
        try {
            dosenDAO.findById(id); // memastikan dosen ada
            if (dosen.getNamaDosen() == null || dosen.getNamaDosen().trim().isEmpty()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Nama Dosen tidak boleh kosong untuk update.");
            }
            dosen.setDosenId(id);
            dosenDAO.update(dosen);
            return dosen;
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Dosen dengan ID " + id + " tidak ditemukan untuk update.");
        }
    }

    // Delete dosen
    @DeleteMapping("/{id}")
    public void deleteDosen(@PathVariable Integer id) {
        try {
            dosenDAO.findById(id); // cek apakah dosen ada
            dosenDAO.delete(id);
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Dosen dengan ID " + id + " tidak ditemukan, tidak dapat dihapus.");
        }
    }
}
