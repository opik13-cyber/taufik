package com.siakad.controller;

import com.siakad.dao.ProdiDAO;
import com.siakad.dao.ProdiViewDAO; // <-- Tambahkan import ini
import com.siakad.model.Prodi;
import com.siakad.model.ProdiView; // <-- Tambahkan import ini
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping("/api/prodi")
public class ProdiController {

    @Autowired
    private ProdiDAO prodiDAO;

    @Autowired // <-- Tambahkan Autowired untuk ProdiViewDAO
    private ProdiViewDAO prodiViewDAO;

    @GetMapping
    public List<ProdiView> getAllProdi() { // <-- Ubah tipe kembalian ke List<ProdiView>
        // Menggunakan ProdiViewDAO untuk mendapatkan data yang lebih lengkap
        return prodiViewDAO.findAll(); //
    }

    @GetMapping("/{id}")
    public Prodi getProdiById(@PathVariable Integer id) {
        // Metode ini bisa tetap mengembalikan Prodi, atau diubah ke ProdiView jika
        // diperlukan.
        // Untuk saat ini, kita biarkan mengembalikan Prodi untuk form edit.
        // Atau, jika form edit juga butuh nama fakultas (meski sudah ada di dropdown),
        // bisa juga diubah untuk mengembalikan ProdiView.
        try {
            return prodiDAO.findById(id); //
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Prodi tidak ditemukan");
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED) // Tambahkan status CREATED
    public Prodi createProdi(@RequestBody Prodi prodi) { // Mengembalikan Prodi yang dibuat
        // Tambahkan validasi jika perlu
        if (prodi.getNamaProdi() == null || prodi.getNamaProdi().trim().isEmpty() || prodi.getFakultasId() == 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Nama Prodi dan Fakultas ID tidak boleh kosong/invalid.");
        }
        prodiDAO.save(prodi); //
        return prodi; // Mengembalikan objek yang diterima sebagai konfirmasi
    }

    @PutMapping("/{id}")
    public Prodi updateProdi(@PathVariable Integer id, @RequestBody Prodi prodi) { // Mengembalikan Prodi yang diupdate
        try {
            prodiDAO.findById(id); // Cek apakah prodi ada, akan throw exception jika tidak
            if (prodi.getNamaProdi() == null || prodi.getNamaProdi().trim().isEmpty() || prodi.getFakultasId() == 0) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Nama Prodi dan Fakultas ID tidak boleh kosong/invalid untuk update.");
            }
            prodi.setProdiId(id); //
            prodiDAO.update(prodi); //
            return prodi;
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Prodi dengan ID " + id + " tidak ditemukan untuk update.");
        }
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT) // Tambahkan status NO_CONTENT
    public void deleteProdi(@PathVariable Integer id) {
        try {
            prodiDAO.findById(id); // Cek apakah ada
            prodiDAO.delete(id); //
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Prodi dengan ID " + id + " tidak ditemukan, tidak dapat dihapus.");
        }
    }
}