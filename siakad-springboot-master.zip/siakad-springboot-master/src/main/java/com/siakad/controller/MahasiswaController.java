package com.siakad.controller;

import com.siakad.dao.MahasiswaDAO;
import com.siakad.dao.MahasiswaViewDAO;
import com.siakad.model.Mahasiswa; // Pastikan import model Mahasiswa benar
import com.siakad.model.MahasiswaView;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/mahasiswa")
public class MahasiswaController {

    @Autowired
    private MahasiswaDAO mahasiswaDAO;

    @Autowired
    private MahasiswaViewDAO mahasiswaViewDAO;

    @GetMapping
    public List<MahasiswaView> getAllMahasiswa() {
        // Menggunakan MahasiswaViewDAO untuk mendapatkan data yang lebih lengkap
        return mahasiswaViewDAO.findAll(); //
    }

    // GET mahasiswa by id
    @GetMapping("/{id}")
    public Mahasiswa getMahasiswaById(@PathVariable Integer id) {
        try {
            return mahasiswaDAO.findById(id); //
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Mahasiswa dengan ID " + id + " tidak ditemukan");
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mahasiswa createMahasiswa(@RequestBody Mahasiswa mahasiswa) {
        if (mahasiswa.getNim() == null || mahasiswa.getNim().trim().isEmpty() ||
                mahasiswa.getNama() == null || mahasiswa.getNama().trim().isEmpty() ||
                mahasiswa.getProdiId() == 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "NIM, Nama, dan Prodi ID tidak boleh kosong/invalid.");
        }

        mahasiswaDAO.save(mahasiswa);
        return mahasiswa;
    }

    // PUT update mahasiswa
    @PutMapping("/{id}")
    public Mahasiswa updateMahasiswa(@PathVariable Integer id, @RequestBody Mahasiswa mahasiswa) {
        try {
            mahasiswaDAO.findById(id); // Cek apakah ada, akan throw exception jika tidak
            if (mahasiswa.getNim() == null || mahasiswa.getNim().trim().isEmpty() ||
                    mahasiswa.getNama() == null || mahasiswa.getNama().trim().isEmpty() ||
                    mahasiswa.getProdiId() == 0) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "NIM, Nama, dan Prodi ID tidak boleh kosong/invalid untuk update.");
            }
            mahasiswa.setMahasiswaId(id);
            mahasiswaDAO.update(mahasiswa);
            return mahasiswa;
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Mahasiswa dengan ID " + id + " tidak ditemukan untuk update.");
        }
    }

    // DELETE mahasiswa by id
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteMahasiswa(@PathVariable Integer id) {
        try {
            mahasiswaDAO.findById(id); // Cek apakah ada
            mahasiswaDAO.delete(id);
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Mahasiswa dengan ID " + id + " tidak ditemukan, tidak dapat dihapus.");
        }
    }
}