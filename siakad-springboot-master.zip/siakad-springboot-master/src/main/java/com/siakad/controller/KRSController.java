package com.siakad.controller;

import com.siakad.dao.KrsDAO;
import com.siakad.dao.KrsViewDAO; // <-- Tambahkan import
import com.siakad.model.Krs;
import com.siakad.model.KrsView; // <-- Tambahkan import
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;
import java.io.ByteArrayOutputStream;
import java.util.stream.Stream;

@RestController
@RequestMapping("/api/krs")
public class KRSController {

    @Autowired
    private KrsDAO krsDAO;

    @Autowired // <-- Tambahkan Autowired untuk KrsViewDAO
    private KrsViewDAO krsViewDAO;

    @GetMapping
    public List<KrsView> getAllKrs() { // <-- Ubah tipe kembalian ke List<KrsView>
        return krsViewDAO.findAll(); // Gunakan KrsViewDAO
    }

    @GetMapping("/{id}")
    public Krs getKrsById(@PathVariable Integer id) {
        // Untuk get by ID, bisa tetap Krs atau KrsView.
        // Jika KrsView, Anda perlu menambahkan findById di KrsViewDAO.
        // Untuk form edit, Krs dasar mungkin cukup karena dropdown diisi terpisah.
        // Kita biarkan Krs untuk saat ini agar konsisten dengan model yang di-POST/PUT.
        try {
            return krsDAO.findById(id); //
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "KRS tidak ditemukan");
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED) // Tambahkan status
    public Krs createKrs(@RequestBody Krs krs) { // Mengembalikan Krs yang dibuat
        // Tambahkan validasi jika perlu
        if (krs.getMahasiswaId() == 0 || krs.getMatkulId() == 0 || krs.getDosenId() == 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Mahasiswa ID, Matkul ID, dan Dosen ID tidak boleh kosong/invalid.");
        }
        krsDAO.save(krs); //
        return krs;
    }

    @PutMapping("/{id}")
    public Krs updateKrs(@PathVariable Integer id, @RequestBody Krs krs) { // Mengembalikan Krs yang diupdate
        try {
            krsDAO.findById(id); // Cek apakah ada
            if (krs.getMahasiswaId() == 0 || krs.getMatkulId() == 0 || krs.getDosenId() == 0) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                        "Mahasiswa ID, Matkul ID, dan Dosen ID tidak boleh kosong/invalid untuk update.");
            }
            krs.setKrsId(id); //
            krsDAO.update(krs); //
            return krs;
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "KRS dengan ID " + id + " tidak ditemukan untuk update.");
        }
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT) // Tambahkan status
    public void deleteKrs(@PathVariable Integer id) {
        try {
            krsDAO.findById(id); // Cek apakah ada
            krsDAO.delete(id); //
        } catch (EmptyResultDataAccessException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "KRS dengan ID " + id + " tidak ditemukan, tidak dapat dihapus.");
        }
    }

    @GetMapping(value = "/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> exportKrsToPdf() {
        List<KrsView> list = krsViewDAO.findAll();

        Document document = new Document(PageSize.A4.rotate());
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            Font headerFont = new Font(Font.HELVETICA, 14, Font.BOLD);
            Paragraph title = new Paragraph("Data Kartu Rencana Studi (KRS)", headerFont);
            title.setAlignment(Element.ALIGN_CENTER);
            title.setSpacingAfter(10);
            document.add(title);

            PdfPTable table = new PdfPTable(7);
            table.setWidthPercentage(100);

            Stream.of("No", "NIM", "Nama Mahasiswa", "Mata Kuliah", "SKS", "Dosen", "Nilai")
                    .forEach(headerTitle -> {
                        PdfPCell header = new PdfPCell(new Phrase(headerTitle));
                        header.setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.addCell(header);
                    });

            int index = 1;
            for (KrsView krs : list) {
                table.addCell(String.valueOf(index++));
                table.addCell(krs.getNim());
                table.addCell(krs.getNamaMahasiswa());
                table.addCell(krs.getNamaMatkul());
                table.addCell(String.valueOf(krs.getSks()));
                table.addCell(krs.getNamaDosen());
                table.addCell(krs.getNilai());
            }

            document.add(table);
            document.close();
        } catch (DocumentException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Gagal membuat PDF");
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=krs.pdf");

        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(out.toByteArray());
    }
}