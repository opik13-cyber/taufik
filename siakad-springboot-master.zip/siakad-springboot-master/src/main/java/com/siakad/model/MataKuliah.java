package com.siakad.model;

public class MataKuliah {
    private int matkulId;
    private String namaMatkul;
    private int sks;

    public MataKuliah() {
    }

    public int getMatkulId() {
        return matkulId;
    }

    public void setMatkulId(int matkulId) {
        this.matkulId = matkulId;
    }

    public String getNamaMatkul() {
        return namaMatkul;
    }

    public void setNamaMatkul(String namaMatkul) {
        this.namaMatkul = namaMatkul;
    }

    public int getSks() {
        return sks;
    }

    public void setSks(int sks) {
        this.sks = sks;
    }
}
