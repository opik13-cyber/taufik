package com.siakad.model;

public class KrsView {
    private int krsId;
    private int mahasiswaId;
    private String nim;
    private String namaMahasiswa;
    private int matkulId;
    private String namaMatkul;
    private int sks;
    private int dosenId;
    private String namaDosen;
    private String nilai;

    public KrsView() {
    }

    // Getter & Setter
    public int getKrsId() {
        return krsId;
    }

    public void setKrsId(int krsId) {
        this.krsId = krsId;
    }

    public int getMahasiswaId() {
        return mahasiswaId;
    }

    public void setMahasiswaId(int mahasiswaId) {
        this.mahasiswaId = mahasiswaId;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getNamaMahasiswa() {
        return namaMahasiswa;
    }

    public void setNamaMahasiswa(String namaMahasiswa) {
        this.namaMahasiswa = namaMahasiswa;
    }

    public int getMatkulId() {
        return matkulId;
    }

    public void setMatkulId(int matkulId) {
        this.matkulId = matkulId;
    }

    public String getNamaMatkul() {
        return namaMatkul;
    }

    public void setNamaMatkul(String namaMatkul) {
        this.namaMatkul = namaMatkul;
    }

    public int getSks() {
        return sks;
    }

    public void setSks(int sks) {
        this.sks = sks;
    }

    public int getDosenId() {
        return dosenId;
    }

    public void setDosenId(int dosenId) {
        this.dosenId = dosenId;
    }

    public String getNamaDosen() {
        return namaDosen;
    }

    public void setNamaDosen(String namaDosen) {
        this.namaDosen = namaDosen;
    }

    public String getNilai() {
        return nilai;
    }

    public void setNilai(String nilai) {
        this.nilai = nilai;
    }
}
