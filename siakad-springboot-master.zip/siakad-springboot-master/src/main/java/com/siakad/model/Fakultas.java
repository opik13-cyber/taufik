package com.siakad.model;

public class Fakultas {
    private int fakultasId;
    private String namaFakultas;

    public Fakultas() {
    }

    public int getFakultasId() {
        return fakultasId;
    }

    public void setFakultasId(int fakultasId) {
        this.fakultasId = fakultasId;
    }

    public String getNamaFakultas() {
        return namaFakultas;
    }

    public void setNamaFakultas(String namaFakultas) {
        this.namaFakultas = namaFakultas;
    }
}
