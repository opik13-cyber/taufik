package com.siakad.model;

public class Krs {
    private int krsId;
    private int mahasiswaId;
    private int matkulId;
    private int dosenId;
    private String nilai;

    public Krs() {
    }

    public int getKrsId() {
        return krsId;
    }

    public void setKrsId(int krsId) {
        this.krsId = krsId;
    }

    public int getMahasiswaId() {
        return mahasiswaId;
    }

    public void setMahasiswaId(int mahasiswaId) {
        this.mahasiswaId = mahasiswaId;
    }

    public int getMatkulId() {
        return matkulId;
    }

    public void setMatkulId(int matkulId) {
        this.matkulId = matkulId;
    }

    public int getDosenId() {
        return dosenId;
    }

    public void setDosenId(int dosenId) {
        this.dosenId = dosenId;
    }

    public String getNilai() {
        return nilai;
    }

    public void setNilai(String nilai) {
        this.nilai = nilai;
    }
}
