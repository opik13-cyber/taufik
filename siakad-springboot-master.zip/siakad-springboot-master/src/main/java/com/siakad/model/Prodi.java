package com.siakad.model;

public class Prodi {
    private int prodiId;
    private String namaProdi;
    private int fakultasId;

    public Prodi() {
    }

    public int getProdiId() {
        return prodiId;
    }

    public void setProdiId(int prodiId) {
        this.prodiId = prodiId;
    }

    public String getNamaProdi() {
        return namaProdi;
    }

    public void setNamaProdi(String namaProdi) {
        this.namaProdi = namaProdi;
    }

    public int getFakultasId() {
        return fakultasId;
    }

    public void setFakultasId(int fakultasId) {
        this.fakultasId = fakultasId;
    }
}
