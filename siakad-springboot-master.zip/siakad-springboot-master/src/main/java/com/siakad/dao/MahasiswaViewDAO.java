package com.siakad.dao;

import com.siakad.model.MahasiswaView;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class MahasiswaViewDAO {
    private final JdbcTemplate jdbcTemplate;

    public MahasiswaViewDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<MahasiswaView> findAll() {
        String sql = """
                    SELECT
                        m.mahasiswa_id AS mahasiswaId,
                        m.nim,
                        m.nama,
                        m.prodi_id AS prodiId,
                        p.nama_prodi AS namaProdi,
                        p.fakultas_id AS fakultasId,
                        f.nama_fakultas AS namaFakultas
                    FROM mahasiswa m
                    LEFT JOIN prodi p ON m.prodi_id = p.prodi_id
                    LEFT JOIN fakultas f ON p.fakultas_id = f.fakultas_id
                """;
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(MahasiswaView.class));
    }

    public MahasiswaView findById(int id) {
        String sql = """
                    SELECT
                        m.mahasiswa_id AS mahasiswaId,
                        m.nim,
                        m.nama,
                        m.prodi_id AS prodiId,
                        p.nama_prodi AS namaProdi,
                        p.fakultas_id AS fakultasId,
                        f.nama_fakultas AS namaFakultas
                    FROM mahasiswa m
                    LEFT JOIN prodi p ON m.prodi_id = p.prodi_id
                    LEFT JOIN fakultas f ON p.fakultas_id = f.fakultas_id
                    WHERE m.mahasiswa_id = ?
                """;
        return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(MahasiswaView.class), id);
    }
}
