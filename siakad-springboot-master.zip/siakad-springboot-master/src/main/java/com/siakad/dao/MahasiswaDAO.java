package com.siakad.dao;

import com.siakad.model.Mahasiswa;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class MahasiswaDAO {
    private final JdbcTemplate jdbcTemplate;

    public MahasiswaDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Mahasiswa> findAll() {
        String sql = "SELECT mahasiswa_id AS mahasiswaId, nim, nama, prodi_id AS prodiId FROM mahasiswa";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Mahasiswa.class));
    }

    public Mahasiswa findById(int id) {
        String sql = "SELECT mahasiswa_id AS mahasiswaId, nim, nama, prodi_id AS prodiId FROM mahasiswa WHERE mahasiswa_id = ?";
        return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(Mahasiswa.class), id);
    }

    public void save(Mahasiswa mhs) {
        String sql = "INSERT INTO mahasiswa (nim, nama, prodi_id) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, mhs.getNim(), mhs.getNama(), mhs.getProdiId());
    }

    public void update(Mahasiswa mhs) {
        String sql = "UPDATE mahasiswa SET nim = ?, nama = ?, prodi_id = ? WHERE mahasiswa_id = ?";
        jdbcTemplate.update(sql, mhs.getNim(), mhs.getNama(), mhs.getProdiId(), mhs.getMahasiswaId());
    }

    public void delete(int id) {
        String sql = "DELETE FROM mahasiswa WHERE mahasiswa_id = ?";
        jdbcTemplate.update(sql, id);
    }
}
