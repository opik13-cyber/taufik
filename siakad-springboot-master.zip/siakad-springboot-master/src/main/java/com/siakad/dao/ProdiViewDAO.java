package com.siakad.dao;

import com.siakad.model.ProdiView;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class ProdiViewDAO {
    private final JdbcTemplate jdbcTemplate;

    public ProdiViewDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<ProdiView> findAll() {
        String sql = """
                    SELECT
                        p.prodi_id AS prodiId,
                        p.nama_prodi AS namaProdi,
                        p.fakultas_id AS fakultasId,
                        f.nama_fakultas AS namaFakultas
                    FROM prodi p
                    LEFT JOIN fakultas f ON p.fakultas_id = f.fakultas_id
                """;
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(ProdiView.class));
    }

    public ProdiView findById(int id) {
        String sql = """
                    SELECT
                        p.prodi_id AS prodiId,
                        p.nama_prodi AS namaProdi,
                        p.fakultas_id AS fakultasId,
                        f.nama_fakultas AS namaFakultas
                    FROM prodi p
                    LEFT JOIN fakultas f ON p.fakultas_id = f.fakultas_id
                    WHERE p.prodi_id = ?
                """;
        return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(ProdiView.class), id);
    }
}
