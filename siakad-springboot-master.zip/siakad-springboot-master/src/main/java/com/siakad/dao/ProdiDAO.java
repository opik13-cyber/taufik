package com.siakad.dao;

import com.siakad.model.Prodi;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class ProdiDAO {
    private final JdbcTemplate jdbcTemplate;

    public ProdiDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Prodi> findAll() {
        String sql = "SELECT prodi_id AS prodiId, nama_prodi AS namaProdi, fakultas_id AS fakultasId FROM prodi";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Prodi.class));
    }

    public Prodi findById(int id) {
        String sql = "SELECT prodi_id AS prodiId, nama_prodi AS namaProdi, fakultas_id AS fakultasId FROM prodi WHERE prodi_id = ?";
        return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(Prodi.class), id);
    }

    public void save(Prodi p) {
        String sql = "INSERT INTO prodi (nama_prodi, fakultas_id) VALUES (?, ?)";
        jdbcTemplate.update(sql, p.getNamaProdi(), p.getFakultasId());
    }

    public void update(Prodi p) {
        String sql = "UPDATE prodi SET nama_prodi = ?, fakultas_id = ? WHERE prodi_id = ?";
        jdbcTemplate.update(sql, p.getNamaProdi(), p.getFakultasId(), p.getProdiId());
    }

    public void delete(int id) {
        String sql = "DELETE FROM prodi WHERE prodi_id = ?";
        jdbcTemplate.update(sql, id);
    }
}
