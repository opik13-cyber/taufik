package com.siakad.dao;

import com.siakad.model.Krs;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class KrsDAO {
    private final JdbcTemplate jdbcTemplate;

    public KrsDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Krs> findAll() {
        String sql = "SELECT krs_id AS krsId, mahasiswa_id AS mahasiswaId, matkul_id AS matkulId, dosen_id AS dosenId, nilai FROM krs";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Krs.class));
    }

    public Krs findById(int id) {
        String sql = "SELECT krs_id AS krsId, mahasiswa_id AS mahasiswaId, matkul_id AS matkulId, dosen_id AS dosenId, nilai FROM krs WHERE krs_id = ?";
        return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(Krs.class), id);
    }

    public void save(Krs krs) {
        String sql = "INSERT INTO krs (mahasiswa_id, matkul_id, dosen_id, nilai) VALUES (?, ?, ?, ?)";
        jdbcTemplate.update(sql, krs.getMahasiswaId(), krs.getMatkulId(), krs.getDosenId(), krs.getNilai());
    }

    public void update(Krs krs) {
        String sql = "UPDATE krs SET mahasiswa_id = ?, matkul_id = ?, dosen_id = ?, nilai = ? WHERE krs_id = ?";
        jdbcTemplate.update(sql, krs.getMahasiswaId(), krs.getMatkulId(), krs.getDosenId(), krs.getNilai(),
                krs.getKrsId());
    }

    public void delete(int id) {
        String sql = "DELETE FROM krs WHERE krs_id = ?";
        jdbcTemplate.update(sql, id);
    }
}
