package com.siakad.dao;

import com.siakad.model.KrsView;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class KrsViewDAO {
    private final JdbcTemplate jdbcTemplate;

    public KrsViewDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<KrsView> findAll() {
        String sql = """
                    SELECT
                        k.krs_id AS krsId,
                        m.mahasiswa_id AS mahasiswaId,
                        m.nim,
                        m.nama AS namaMahasiswa,
                        mk.matkul_id AS matkulId,
                        mk.nama_matkul AS namaMatkul,
                        mk.sks,
                        d.dosen_id AS dosenId,
                        d.nama_dosen AS namaDosen,
                        k.nilai
                    FROM krs k
                    LEFT JOIN mahasiswa m ON k.mahasiswa_id = m.mahasiswa_id
                    LEFT JOIN matakuliah mk ON k.matkul_id = mk.matkul_id
                    LEFT JOIN dosen d ON k.dosen_id = d.dosen_id
                """;
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(KrsView.class));
    }

    public KrsView findById(int id) {
        String sql = """
                    SELECT
                        k.krs_id AS krsId,
                        m.mahasiswa_id AS mahasiswaId,
                        m.nim,
                        m.nama AS namaMahasiswa,
                        mk.matkul_id AS matkulId,
                        mk.nama_matkul AS namaMatkul,
                        mk.sks,
                        d.dosen_id AS dosenId,
                        d.nama_dosen AS namaDosen,
                        k.nilai
                    FROM krs k
                    LEFT JOIN mahasiswa m ON k.mahasiswa_id = m.mahasiswa_id
                    LEFT JOIN matakuliah mk ON k.matkul_id = mk.matkul_id
                    LEFT JOIN dosen d ON k.dosen_id = d.dosen_id
                    WHERE k.krs_id = ?
                """;
        return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(KrsView.class), id);
    }
}
