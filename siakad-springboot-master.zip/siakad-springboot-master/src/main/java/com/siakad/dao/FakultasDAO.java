package com.siakad.dao;

import com.siakad.model.Fakultas;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class FakultasDAO {
    private final JdbcTemplate jdbcTemplate;

    public FakultasDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Fakultas> findAll() {
        String sql = "SELECT fakultas_id AS fakultasId, nama_fakultas AS namaFakultas FROM fakultas";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Fakultas.class));
    }

    public Fakultas findById(int id) {
        String sql = "SELECT fakultas_id AS fakultasId, nama_fakultas AS namaFakultas FROM fakultas WHERE fakultas_id = ?";
        return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(Fakultas.class), id);
    }

    public void save(Fakultas f) {
        String sql = "INSERT INTO fakultas (nama_fakultas) VALUES (?)";
        jdbcTemplate.update(sql, f.getNamaFakultas());
    }

    public void update(Fakultas f) {
        String sql = "UPDATE fakultas SET nama_fakultas = ? WHERE fakultas_id = ?";
        jdbcTemplate.update(sql, f.getNamaFakultas(), f.getFakultasId());
    }

    public void delete(int id) {
        String sql = "DELETE FROM fakultas WHERE fakultas_id = ?";
        jdbcTemplate.update(sql, id);
    }
}
