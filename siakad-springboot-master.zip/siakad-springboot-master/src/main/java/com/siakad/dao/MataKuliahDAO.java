package com.siakad.dao;

import com.siakad.model.MataKuliah;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class MataKuliahDAO {
    private final JdbcTemplate jdbcTemplate;

    public MataKuliahDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<MataKuliah> findAll() {
        String sql = "SELECT matkul_id AS matkulId, nama_matkul AS namaMatkul, sks FROM matakuliah";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(MataKuliah.class));
    }

    public MataKuliah findById(int id) {
        String sql = "SELECT matkul_id AS matkulId, nama_matkul AS namaMatkul, sks FROM matakuliah WHERE matkul_id = ?";
        return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(MataKuliah.class), id);
    }

    public void save(MataKuliah mk) {
        String sql = "INSERT INTO matakuliah (nama_matkul, sks) VALUES (?, ?)";
        jdbcTemplate.update(sql, mk.getNamaMatkul(), mk.getSks());
    }

    public void update(MataKuliah mk) {
        String sql = "UPDATE matakuliah SET nama_matkul = ?, sks = ? WHERE matkul_id = ?";
        jdbcTemplate.update(sql, mk.getNamaMatkul(), mk.getSks(), mk.getMatkulId());
    }

    public void delete(int id) {
        String sql = "DELETE FROM matakuliah WHERE matkul_id = ?";
        jdbcTemplate.update(sql, id);
    }
}
