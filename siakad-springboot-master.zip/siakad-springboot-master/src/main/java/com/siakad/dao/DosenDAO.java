package com.siakad.dao;

import com.siakad.model.Dosen;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class DosenDAO {
    private final JdbcTemplate jdbcTemplate;

    public DosenDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Dosen> findAll() {
        String sql = "SELECT dosen_id AS dosenId, nama_dosen AS namaDosen FROM dosen";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Dosen.class));
    }

    public Dosen findById(int id) {
        String sql = "SELECT dosen_id AS dosenId, nama_dosen AS namaDosen FROM dosen WHERE dosen_id = ?";
        return jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(Dosen.class), id);
    }

    public void save(Dosen d) {
        String sql = "INSERT INTO dosen (nama_dosen) VALUES (?)";
        jdbcTemplate.update(sql, d.getNamaDosen());
    }

    public void update(Dosen d) {
        String sql = "UPDATE dosen SET nama_dosen = ? WHERE dosen_id = ?";
        jdbcTemplate.update(sql, d.getNamaDosen(), d.getDosenId());
    }

    public void delete(int id) {
        String sql = "DELETE FROM dosen WHERE dosen_id = ?";
        jdbcTemplate.update(sql, id);
    }
}
