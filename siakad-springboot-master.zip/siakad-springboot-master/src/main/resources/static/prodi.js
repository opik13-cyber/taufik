const PRODI_API_URL = '/api/prodi';
const FAKULTAS_API_URL = '/api/fakultas'; 
let currentProdiId = null;
let prodiModalInstance = null;

document.addEventListener('DOMContentLoaded', function () {
    prodiModalInstance = new bootstrap.Modal(document.getElementById('prodiModal'));
    loadProdi();
    document.getElementById('prodiModal').addEventListener('show.bs.modal', async function () {
        await populateFakultasDropdown();
    });
});

async function populateFakultasDropdown() {
    try {
        const response = await fetch(FAKULTAS_API_URL);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const fakultasList = await response.json();
        const selectElement = document.getElementById('fakultasId');
        const selectedFakultasId = selectElement.value;

        selectElement.innerHTML = '<option value="">Pilih Fakultas</option>'; 

        fakultasList.forEach(fakultas => {
            const option = document.createElement('option');
            option.value = fakultas.fakultasId;
            option.textContent = fakultas.namaFakultas; 
            selectElement.appendChild(option);
        });

        if (selectedFakultasId) {
            selectElement.value = selectedFakultasId;
        }

    } catch (error) {
        console.error('Error populating fakultas dropdown:', error);
        alert('Gagal memuat daftar fakultas: ' + error.message);
    }
}

async function loadProdi() {
    try {
        const response = await fetch(PRODI_API_URL);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const prodiList = await response.json(); // Ini sekarang akan menjadi List<ProdiView>
        const tableBody = document.getElementById('prodiTableBody');
        tableBody.innerHTML = ''; 

        if (!prodiList || prodiList.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="4" class="text-center">Tidak ada data program studi.</td></tr>';
            return;
        }

        prodiList.forEach(prodi => {
            // 'prodi' sekarang adalah objek ProdiView dan memiliki properti 'namaFakultas'
            // 'fakultasId' juga ada di ProdiView karena dipilih di ProdiViewDAO
            const row = `<tr>
                            <td>${prodi.prodiId}</td>
                            <td>${prodi.namaProdi}</td>
                            <td>${prodi.namaFakultas || 'N/A'}</td> <td class="table-actions">
                                <button class="btn btn-sm btn-warning" onclick="prepareEditProdi(${prodi.prodiId}, '${prodi.namaProdi}', ${prodi.fakultasId})">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="deleteProdi(${prodi.prodiId})">
                                    <i class="fas fa-trash"></i> Hapus
                                </button>
                            </td>
                        </tr>`;
            tableBody.innerHTML += row;
        });
    } catch (error) {
        console.error('Error loading prodi:', error);
        alert('Gagal memuat data prodi: ' + error.message);
        document.getElementById('prodiTableBody').innerHTML = `<tr><td colspan="4" class="text-center">Error: ${error.message}</td></tr>`;
    }
}

// prepareSaveProdi tetap sama
async function prepareSaveProdi() {
    currentProdiId = null;
    document.getElementById('prodiForm').reset();
    document.getElementById('prodiModalLabel').textContent = 'Tambah Program Studi';
}

// prepareEditProdi tetap menggunakan fakultasIdValue untuk men-set dropdown
async function prepareEditProdi(id, namaProdi, fakultasIdValue) {
    currentProdiId = id;
    document.getElementById('prodiId').value = id;
    document.getElementById('namaProdi').value = namaProdi;
    
    await populateFakultasDropdown(); // Pastikan dropdown terisi
    document.getElementById('fakultasId').value = fakultasIdValue; // Set fakultas yang sesuai
    
    document.getElementById('prodiModalLabel').textContent = 'Edit Program Studi';
    prodiModalInstance.show();
}

// saveProdi tetap sama, mengirim fakultasId
async function saveProdi() {
    const namaProdi = document.getElementById('namaProdi').value;
    const fakultasId = document.getElementById('fakultasId').value;

    if (!namaProdi.trim()) {
        alert('Nama Prodi tidak boleh kosong.');
        return;
    }
    if (!fakultasId) {
        alert('Fakultas harus dipilih.');
        return;
    }

    const prodiData = {
        namaProdi: namaProdi,
        fakultasId: parseInt(fakultasId) 
    };

    let method = 'POST';
    let url = PRODI_API_URL;

    if (currentProdiId) {
        method = 'PUT';
        url = `${PRODI_API_URL}/${currentProdiId}`;
        prodiData.prodiId = currentProdiId; 
    }

    try {
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(prodiData),
        });

        if (!response.ok) {
             const errorData = await response.text();
             throw new Error(`HTTP error! status: ${response.status}, message: ${errorData}`);
        }
        
        prodiModalInstance.hide();
        loadProdi(); 
        alert(`Program Studi berhasil ${currentProdiId ? 'diperbarui' : 'disimpan'}!`);
    } catch (error) {
        console.error('Error saving prodi:', error);
        alert('Gagal menyimpan prodi: ' + error.message);
    }
}

// deleteProdi tetap sama
async function deleteProdi(id) {
    if (!confirm('Apakah Anda yakin ingin menghapus program studi ini?')) {
        return;
    }

    try {
        const response = await fetch(`${PRODI_API_URL}/${id}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            const errorData = await response.text();
            throw new Error(`HTTP error! status: ${response.status}, message: ${errorData}`);
        }
        loadProdi(); 
        alert('Program Studi berhasil dihapus!');
    } catch (error) {
        console.error('Error deleting prodi:', error);
        alert('Gagal menghapus prodi: ' + error.message);
    }
}