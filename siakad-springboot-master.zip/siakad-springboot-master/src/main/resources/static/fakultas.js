const API_URL = '/api/fakultas';
let currentFakultasId = null;
let fakultasModal = null; // Variable to hold the modal instance

document.addEventListener('DOMContentLoaded', function () {
    fakultasModal = new bootstrap.Modal(document.getElementById('fakultasModal'));
    loadFakultas();
});

async function loadFakultas() {
    try {
        const response = await fetch(API_URL);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const fakultasList = await response.json();
        const tableBody = document.getElementById('fakultasTableBody');
        tableBody.innerHTML = ''; // Clear existing rows
        fakultasList.forEach(fakultas => {
            const row = `<tr>
                            <td>${fakultas.fakultasId}</td>
                            <td>${fakultas.namaFakultas}</td>
                            <td class="table-actions">
                                <button class="btn btn-sm btn-warning" onclick="prepareEdit(${fakultas.fakultasId}, '${fakultas.namaFakultas}')">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="deleteFakultas(${fakultas.fakultasId})">
                                    <i class="fas fa-trash"></i> Hapus
                                </button>
                            </td>
                        </tr>`;
            tableBody.innerHTML += row;
        });
    } catch (error) {
        console.error('Error loading fakultas:', error);
        alert('Gagal memuat data fakultas: ' + error.message);
    }
}

function prepareSave() {
    currentFakultasId = null;
    document.getElementById('fakultasForm').reset();
    document.getElementById('fakultasModalLabel').textContent = 'Tambah Fakultas';
    // fakultasModal.show(); // Modal will be shown by button's data-bs-target
}

async function prepareEdit(id, namaFakultas) {
    currentFakultasId = id;
    document.getElementById('fakultasId').value = id;
    document.getElementById('namaFakultas').value = namaFakultas;
    document.getElementById('fakultasModalLabel').textContent = 'Edit Fakultas';
    fakultasModal.show();
}

async function saveFakultas() {
    const namaFakultas = document.getElementById('namaFakultas').value;
    if (!namaFakultas.trim()) {
        alert('Nama Fakultas tidak boleh kosong.');
        return;
    }

    const fakultasData = {
        namaFakultas: namaFakultas
    };

    let method = 'POST';
    let url = API_URL;

    if (currentFakultasId) {
        method = 'PUT';
        url = `${API_URL}/${currentFakultasId}`;
        fakultasData.fakultasId = currentFakultasId; // Include ID for update consistency
    }

    try {
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(fakultasData),
        });

        if (!response.ok) {
             const errorData = await response.text(); // Or response.json() if backend sends JSON error
             throw new Error(`HTTP error! status: ${response.status}, message: ${errorData}`);
        }
        
        fakultasModal.hide();
        loadFakultas(); // Refresh the list
        alert(`Fakultas berhasil ${currentFakultasId ? 'diperbarui' : 'disimpan'}!`);
    } catch (error) {
        console.error('Error saving fakultas:', error);
        alert('Gagal menyimpan fakultas: ' + error.message);
    }
}

async function deleteFakultas(id) {
    if (!confirm('Apakah Anda yakin ingin menghapus fakultas ini?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            const errorData = await response.text();
            throw new Error(`HTTP error! status: ${response.status}, message: ${errorData}`);
        }
        loadFakultas(); // Refresh the list
        alert('Fakultas berhasil dihapus!');
    } catch (error) {
        console.error('Error deleting fakultas:', error);
        alert('Gagal menghapus fakultas: ' + error.message);
    }
}