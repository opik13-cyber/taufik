const MAHASISWA_API_URL = '/api/mahasiswa';
const PRODI_API_URL_FOR_DROPDOWN = '/api/prodi';
let currentMahasiswaId = null;
let mahasiswaModalInstance = null;

document.addEventListener('DOMContentLoaded', function () {
    mahasiswaModalInstance = new bootstrap.Modal(document.getElementById('mahasiswaModal'));
    loadMahasiswa();

    document.getElementById('mahasiswaModal').addEventListener('show.bs.modal', async function () {
        await populateProdiDropdown();
    });
});

async function populateProdiDropdown() {
    try {
        const response = await fetch(PRODI_API_URL_FOR_DROPDOWN);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status} while fetching prodi list.`);
        }
        const prodiList = await response.json();
        const selectElement = document.getElementById('prodiId');
        const selectedProdiId = selectElement.value; 

        selectElement.innerHTML = '<option value="">Pilih Program Studi</option>'; 

        prodiList.forEach(prodi => {
            const option = document.createElement('option');
            option.value = prodi.prodiId;
            option.textContent = prodi.namaProdi;
            selectElement.appendChild(option);
        });

        if (selectedProdiId) {
            selectElement.value = selectedProdiId; 
        }

    } catch (error) {
        console.error('Error populating prodi dropdown:', error);
        alert('Gagal memuat daftar program studi: ' + error.message);
    }
}

async function loadMahasiswa() {
    try {
        const response = await fetch(MAHASISWA_API_URL);
        if (!response.ok) {
            if (response.status === 404) {
                 console.warn(`Endpoint ${MAHASISWA_API_URL} not found. Please ensure a REST controller for Mahasiswa is available.`);
                 alert(`Gagal memuat data mahasiswa: Endpoint ${MAHASISWA_API_URL} tidak ditemukan. Pastikan REST API untuk Mahasiswa sudah ada.`);
                 document.getElementById('mahasiswaTableBody').innerHTML = '<tr><td colspan="5" class="text-center">Gagal memuat data. API tidak ditemukan.</td></tr>';
                 return;
            }
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const mahasiswaList = await response.json(); // Ini sekarang akan menjadi List<MahasiswaView>
        const tableBody = document.getElementById('mahasiswaTableBody');
        tableBody.innerHTML = ''; 

        if (!mahasiswaList || mahasiswaList.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Tidak ada data mahasiswa.</td></tr>';
            return;
        }

        mahasiswaList.forEach(mhs => {
            // 'mhs' sekarang adalah objek MahasiswaView dan memiliki properti 'namaProdi'
            // dan 'prodiId' juga masih ada di MahasiswaView dari join tabel prodi p.prodi_id
            const row = `<tr>
                            <td>${mhs.mahasiswaId}</td>
                            <td>${mhs.nim}</td>
                            <td>${mhs.nama}</td>
                            <td>${mhs.namaProdi || 'N/A'}</td> <td class="table-actions">
                                <button class="btn btn-sm btn-warning" onclick="prepareEditMahasiswa(${mhs.mahasiswaId}, '${mhs.nim}', '${mhs.nama}', ${mhs.prodiId})">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="deleteMahasiswa(${mhs.mahasiswaId})">
                                    <i class="fas fa-trash"></i> Hapus
                                </button>
                            </td>
                        </tr>`;
            tableBody.innerHTML += row;
        });
    } catch (error) {
        console.error('Error loading mahasiswa:', error);
        alert('Gagal memuat data mahasiswa: ' + error.message);
        document.getElementById('mahasiswaTableBody').innerHTML = `<tr><td colspan="5" class="text-center">Error: ${error.message}</td></tr>`;
    }
}

// prepareSaveMahasiswa tetap sama
async function prepareSaveMahasiswa() {
    currentMahasiswaId = null;
    document.getElementById('mahasiswaForm').reset();
    document.getElementById('mahasiswaModalLabel').textContent = 'Tambah Mahasiswa';
}

// prepareEditMahasiswa tetap menggunakan prodiId untuk men-set dropdown
async function prepareEditMahasiswa(id, nim, nama, prodiIdValue) {
    currentMahasiswaId = id;
    document.getElementById('mahasiswaId').value = id;
    document.getElementById('nim').value = nim;
    document.getElementById('nama').value = nama;

    await populateProdiDropdown(); 
    document.getElementById('prodiId').value = prodiIdValue; 

    document.getElementById('mahasiswaModalLabel').textContent = 'Edit Mahasiswa';
    mahasiswaModalInstance.show();
}

// saveMahasiswa tetap sama, mengirim prodiId
async function saveMahasiswa() {
    const nim = document.getElementById('nim').value;
    const nama = document.getElementById('nama').value;
    const prodiId = document.getElementById('prodiId').value;

    if (!nim.trim() || !nama.trim()) {
        alert('NIM dan Nama Mahasiswa tidak boleh kosong.');
        return;
    }
    if (!prodiId) {
        alert('Program Studi harus dipilih.');
        return;
    }

    const mahasiswaData = {
        nim: nim,
        nama: nama,
        prodiId: parseInt(prodiId)
    };

    let method = 'POST';
    let url = MAHASISWA_API_URL;

    if (currentMahasiswaId) {
        method = 'PUT';
        url = `${MAHASISWA_API_URL}/${currentMahasiswaId}`;
        mahasiswaData.mahasiswaId = currentMahasiswaId;
    }

    try {
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(mahasiswaData),
        });

        if (!response.ok) {
             const errorData = await response.text();
             throw new Error(`HTTP error! status: ${response.status}, message: ${errorData}`);
        }
        
        mahasiswaModalInstance.hide();
        loadMahasiswa();
        alert(`Mahasiswa berhasil ${currentMahasiswaId ? 'diperbarui' : 'disimpan'}!`);
    } catch (error) {
        console.error('Error saving mahasiswa:', error);
        alert('Gagal menyimpan mahasiswa: ' + error.message + ` (Pastikan API ${MAHASISWA_API_URL} sudah benar).`);
    }
}

// deleteMahasiswa tetap sama
async function deleteMahasiswa(id) {
    if (!confirm('Apakah Anda yakin ingin menghapus mahasiswa ini?')) {
        return;
    }

    try {
        const response = await fetch(`${MAHASISWA_API_URL}/${id}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            const errorData = await response.text();
            throw new Error(`HTTP error! status: ${response.status}, message: ${errorData}`);
        }
        loadMahasiswa();
        alert('Mahasiswa berhasil dihapus!');
    } catch (error) {
        console.error('Error deleting mahasiswa:', error);
        alert('Gagal menghapus mahasiswa: ' + error.message + ` (Pastikan API ${MAHASISWA_API_URL} sudah benar).`);
    }
}