const KRS_API_URL = '/api/krs';
const MAHASISWA_API_URL_FOR_DROPDOWN = '/api/mahasiswa'; // Asumsi mengembalikan MahasiswaView
const MATAKULIAH_API_URL_FOR_DROPDOWN = '/api/matakuliah';
const DOSEN_API_URL_FOR_DROPDOWN = '/api/dosen';

let currentKrsId = null;
let krsModalInstance = null;

document.addEventListener('DOMContentLoaded', function () {
    krsModalInstance = new bootstrap.Modal(document.getElementById('krsModal'));
    loadKrs();

    // Populate dropdowns when modal is about to be shown
    document.getElementById('krsModal').addEventListener('show.bs.modal', async function () {
        await populateMahasiswaDropdown();
        await populateMatakuliahDropdown();
        await populateDosenDropdown();
    });
});

async function populateMahasiswaDropdown() {
    try {
        const response = await fetch(MAHASISWA_API_URL_FOR_DROPDOWN); // API Mahasiswa
        if (!response.ok) throw new Error(`Error fetching mahasiswa: ${response.statusText}`);
        const mahasiswaList = await response.json(); // Harusnya List<MahasiswaView>
        const select = document.getElementById('mahasiswaId');
        const currentValue = select.value;
        select.innerHTML = '<option value="">Pilih Mahasiswa</option>';
        mahasiswaList.forEach(mhs => {
            // MahasiswaView memiliki nim dan nama
            select.innerHTML += `<option value="${mhs.mahasiswaId}">${mhs.nim} - ${mhs.nama}</option>`;
        });
        if (currentValue) select.value = currentValue;
    } catch (error) {
        console.error('Error populating mahasiswa dropdown:', error);
    }
}

async function populateMatakuliahDropdown() {
    try {
        const response = await fetch(MATAKULIAH_API_URL_FOR_DROPDOWN); // API Matakuliah
        if (!response.ok) throw new Error(`Error fetching matakuliah: ${response.statusText}`);
        const matakuliahList = await response.json();
        const select = document.getElementById('matkulId');
        const currentValue = select.value;
        select.innerHTML = '<option value="">Pilih Mata Kuliah</option>';
        matakuliahList.forEach(mk => {
            select.innerHTML += `<option value="${mk.matkulId}">${mk.namaMatkul} (${mk.sks} SKS)</option>`;
        });
        if (currentValue) select.value = currentValue;
    } catch (error) {
        console.error('Error populating matakuliah dropdown:', error);
    }
}

async function populateDosenDropdown() {
    try {
        const response = await fetch(DOSEN_API_URL_FOR_DROPDOWN); // API Dosen
        if (!response.ok) throw new Error(`Error fetching dosen: ${response.statusText}`);
        const dosenList = await response.json();
        const select = document.getElementById('dosenId');
        const currentValue = select.value;
        select.innerHTML = '<option value="">Pilih Dosen</option>';
        dosenList.forEach(dosen => {
            select.innerHTML += `<option value="${dosen.dosenId}">${dosen.namaDosen}</option>`;
        });
        if (currentValue) select.value = currentValue;
    } catch (error) {
        console.error('Error populating dosen dropdown:', error);
    }
}


async function loadKrs() {
    try {
        const response = await fetch(KRS_API_URL);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const krsList = await response.json(); // Ini adalah List<KrsView>
        const tableBody = document.getElementById('krsTableBody');
        tableBody.innerHTML = '';

        if (!krsList || krsList.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="8" class="text-center">Tidak ada data KRS.</td></tr>';
            return;
        }

        krsList.forEach(krs => {
            // krs adalah objek KrsView
            const row = `<tr>
                            <td>${krs.krsId}</td>
                            <td>${krs.nim || 'N/A'}</td>
                            <td>${krs.namaMahasiswa || 'N/A'}</td>
                            <td>${krs.namaMatkul || 'N/A'}</td>
                            <td>${krs.sks || 'N/A'}</td>
                            <td>${krs.namaDosen || 'N/A'}</td>
                            <td>${krs.nilai || ''}</td>
                            <td class="table-actions">
                                <button class="btn btn-sm btn-warning" 
                                    onclick="prepareEditKrs(${krs.krsId}, ${krs.mahasiswaId}, ${krs.matkulId}, ${krs.dosenId}, '${krs.nilai || ''}')">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="deleteKrs(${krs.krsId})">
                                    <i class="fas fa-trash"></i> Hapus
                                </button>
                            </td>
                        </tr>`;
            tableBody.innerHTML += row;
        });
    } catch (error) {
        console.error('Error loading KRS:', error);
        alert('Gagal memuat data KRS: ' + error.message);
        document.getElementById('krsTableBody').innerHTML = `<tr><td colspan="8" class="text-center">Error: ${error.message}</td></tr>`;
    }
}

function prepareSaveKrs() {
    currentKrsId = null;
    document.getElementById('krsForm').reset();
    document.getElementById('krsModalLabel').textContent = 'Tambah Data KRS';
    // Dropdowns akan di-populate oleh event listener 'show.bs.modal'
}

async function prepareEditKrs(krsId, mahasiswaId, matkulId, dosenId, nilai) {
    currentKrsId = krsId;
    document.getElementById('krsModalLabel').textContent = 'Edit Data KRS';
    document.getElementById('krsId').value = krsId;
    
    // Populate dropdowns and then set values
    await populateMahasiswaDropdown();
    document.getElementById('mahasiswaId').value = mahasiswaId;
    
    await populateMatakuliahDropdown();
    document.getElementById('matkulId').value = matkulId;
    
    await populateDosenDropdown();
    document.getElementById('dosenId').value = dosenId;
    
    document.getElementById('nilai').value = nilai;
    
    krsModalInstance.show();
}

async function saveKrs() {
    const mahasiswaId = document.getElementById('mahasiswaId').value;
    const matkulId = document.getElementById('matkulId').value;
    const dosenId = document.getElementById('dosenId').value;
    const nilai = document.getElementById('nilai').value;

    if (!mahasiswaId || !matkulId || !dosenId) {
        alert('Mahasiswa, Mata Kuliah, dan Dosen harus dipilih.');
        return;
    }

    const krsData = {
        mahasiswaId: parseInt(mahasiswaId),
        matkulId: parseInt(matkulId),
        dosenId: parseInt(dosenId),
        nilai: nilai.trim() // Nilai bisa string
    };

    let method = 'POST';
    let url = KRS_API_URL;

    if (currentKrsId) {
        method = 'PUT';
        url = `${KRS_API_URL}/${currentKrsId}`;
        krsData.krsId = currentKrsId;
    }

    try {
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(krsData),
        });

        if (!response.ok) {
            const errorData = await response.text();
            throw new Error(`HTTP error! status: ${response.status}, message: ${errorData}`);
        }
        
        krsModalInstance.hide();
        loadKrs();
        alert(`Data KRS berhasil ${currentKrsId ? 'diperbarui' : 'disimpan'}!`);
    } catch (error) {
        console.error('Error saving KRS:', error);
        alert('Gagal menyimpan data KRS: ' + error.message);
    }
}

async function deleteKrs(id) {
    if (!confirm('Apakah Anda yakin ingin menghapus data KRS ini?')) {
        return;
    }
    try {
        const response = await fetch(`${KRS_API_URL}/${id}`, { method: 'DELETE' });
        if (!response.ok) {
            const errorData = await response.text();
            throw new Error(`HTTP error! status: ${response.status}, message: ${errorData}`);
        }
        loadKrs();
        alert('Data KRS berhasil dihapus!');
    } catch (error) {
        console.error('Error deleting KRS:', error);
        alert('Gagal menghapus data KRS: ' + error.message);
    }
}