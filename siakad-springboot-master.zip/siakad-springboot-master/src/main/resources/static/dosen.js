const DOSEN_API_URL = '/api/dosen';
let currentDosenId = null;
let dosenModalInstance = null;

document.addEventListener('DOMContentLoaded', function () {
    dosenModalInstance = new bootstrap.Modal(document.getElementById('dosenModal'));
    loadDosen();
});

async function loadDosen() {
    try {
        const response = await fetch(DOSEN_API_URL);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const dosenList = await response.json();
        const tableBody = document.getElementById('dosenTableBody');
        tableBody.innerHTML = ''; // Clear existing rows

        if (!dosenList || dosenList.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="3" class="text-center">Tidak ada data dosen.</td></tr>';
            return;
        }

        dosenList.forEach(dosen => {
            const row = `<tr>
                            <td>${dosen.dosenId}</td>
                            <td>${dosen.namaDosen}</td>
                            <td class="table-actions">
                                <button class="btn btn-sm btn-warning" onclick="prepareEditDosen(${dosen.dosenId}, '${dosen.namaDosen}')">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="deleteDosen(${dosen.dosenId})">
                                    <i class="fas fa-trash"></i> Hapus
                                </button>
                            </td>
                        </tr>`;
            tableBody.innerHTML += row;
        });
    } catch (error) {
        console.error('Error loading dosen:', error);
        alert('Gagal memuat data dosen: ' + error.message);
        document.getElementById('dosenTableBody').innerHTML = `<tr><td colspan="3" class="text-center">Error: ${error.message}</td></tr>`;
    }
}

function prepareSaveDosen() {
    currentDosenId = null;
    document.getElementById('dosenForm').reset();
    document.getElementById('dosenModalLabel').textContent = 'Tambah Dosen';
    // dosenModalInstance.show(); // Modal akan ditampilkan oleh tombol data-bs-target
}

async function prepareEditDosen(id, namaDosen) {
    currentDosenId = id;
    document.getElementById('dosenId').value = id;
    document.getElementById('namaDosen').value = namaDosen;
    document.getElementById('dosenModalLabel').textContent = 'Edit Dosen';
    dosenModalInstance.show();
}

async function saveDosen() {
    const namaDosen = document.getElementById('namaDosen').value;
    if (!namaDosen.trim()) {
        alert('Nama Dosen tidak boleh kosong.');
        return;
    }

    const dosenData = {
        namaDosen: namaDosen //
    };

    let method = 'POST';
    let url = DOSEN_API_URL;

    if (currentDosenId) {
        method = 'PUT';
        url = `${DOSEN_API_URL}/${currentDosenId}`;
        dosenData.dosenId = currentDosenId; // Sertakan ID untuk update
    }

    try {
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(dosenData),
        });

        if (!response.ok) {
             const errorData = await response.text(); 
             throw new Error(`HTTP error! status: ${response.status}, message: ${errorData}`);
        }
        
        dosenModalInstance.hide();
        loadDosen(); // Refresh daftar
        alert(`Dosen berhasil ${currentDosenId ? 'diperbarui' : 'disimpan'}!`);
    } catch (error) {
        console.error('Error saving dosen:', error);
        alert('Gagal menyimpan dosen: ' + error.message);
    }
}

async function deleteDosen(id) {
    if (!confirm('Apakah Anda yakin ingin menghapus dosen ini?')) {
        return;
    }

    try {
        const response = await fetch(`${DOSEN_API_URL}/${id}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            const errorData = await response.text();
            throw new Error(`HTTP error! status: ${response.status}, message: ${errorData}`);
        }
        loadDosen(); // Refresh daftar
        alert('Dosen berhasil dihapus!');
    } catch (error) {
        console.error('Error deleting dosen:', error);
        alert('Gagal menghapus dosen: ' + error.message);
    }
}