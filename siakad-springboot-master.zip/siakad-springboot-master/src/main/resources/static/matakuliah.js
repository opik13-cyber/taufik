const MATAKULIAH_API_URL = '/api/matakuliah';
let currentMatkulId = null;
let matakuliahModalInstance = null;

document.addEventListener('DOMContentLoaded', function () {
    matakuliahModalInstance = new bootstrap.Modal(document.getElementById('matakuliahModal'));
    loadMatakuliah();
});

async function loadMatakuliah() {
    try {
        const response = await fetch(MATAKULIAH_API_URL);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const matakuliahList = await response.json();
        const tableBody = document.getElementById('matakuliahTableBody');
        tableBody.innerHTML = ''; // Clear existing rows

        if (!matakuliahList || matakuliahList.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="4" class="text-center">Tidak ada data mata kuliah.</td></tr>';
            return;
        }

        matakuliahList.forEach(mk => {
            const row = `<tr>
                            <td>${mk.matkulId}</td>
                            <td>${mk.namaMatkul}</td>
                            <td>${mk.sks}</td>
                            <td class="table-actions">
                                <button class="btn btn-sm btn-warning" onclick="prepareEditMatakuliah(${mk.matkulId}, '${mk.namaMatkul}', ${mk.sks})">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="deleteMatakuliah(${mk.matkulId})">
                                    <i class="fas fa-trash"></i> Hapus
                                </button>
                            </td>
                        </tr>`;
            tableBody.innerHTML += row;
        });
    } catch (error) {
        console.error('Error loading mata kuliah:', error);
        alert('Gagal memuat data mata kuliah: ' + error.message);
        document.getElementById('matakuliahTableBody').innerHTML = `<tr><td colspan="4" class="text-center">Error: ${error.message}</td></tr>`;
    }
}

function prepareSaveMatakuliah() {
    currentMatkulId = null;
    document.getElementById('matakuliahForm').reset();
    document.getElementById('matakuliahModalLabel').textContent = 'Tambah Mata Kuliah';
    // matakuliahModalInstance.show(); // Modal akan ditampilkan oleh tombol data-bs-target
}

async function prepareEditMatakuliah(id, namaMatkul, sks) {
    currentMatkulId = id;
    document.getElementById('matkulId').value = id;
    document.getElementById('namaMatkul').value = namaMatkul;
    document.getElementById('sks').value = sks;
    document.getElementById('matakuliahModalLabel').textContent = 'Edit Mata Kuliah';
    matakuliahModalInstance.show();
}

async function saveMatakuliah() {
    const namaMatkul = document.getElementById('namaMatkul').value;
    const sks = document.getElementById('sks').value;

    if (!namaMatkul.trim()) {
        alert('Nama Mata Kuliah tidak boleh kosong.');
        return;
    }
    if (!sks || parseInt(sks) <= 0) {
        alert('SKS harus diisi dan lebih besar dari 0.');
        return;
    }

    const matakuliahData = {
        namaMatkul: namaMatkul,
        sks: parseInt(sks) // Model MataKuliah memiliki sks sebagai int
    };

    let method = 'POST';
    let url = MATAKULIAH_API_URL;

    if (currentMatkulId) {
        method = 'PUT';
        url = `${MATAKULIAH_API_URL}/${currentMatkulId}`;
        matakuliahData.matkulId = currentMatkulId; // Sertakan ID untuk update
    }

    try {
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(matakuliahData),
        });

        if (!response.ok) {
             const errorData = await response.text(); 
             throw new Error(`HTTP error! status: ${response.status}, message: ${errorData}`);
        }
        
        matakuliahModalInstance.hide();
        loadMatakuliah(); // Refresh daftar
        alert(`Mata Kuliah berhasil ${currentMatkulId ? 'diperbarui' : 'disimpan'}!`);
    } catch (error) {
        console.error('Error saving mata kuliah:', error);
        alert('Gagal menyimpan mata kuliah: ' + error.message);
    }
}

async function deleteMatakuliah(id) {
    if (!confirm('Apakah Anda yakin ingin menghapus mata kuliah ini?')) {
        return;
    }

    try {
        const response = await fetch(`${MATAKULIAH_API_URL}/${id}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            const errorData = await response.text();
            throw new Error(`HTTP error! status: ${response.status}, message: ${errorData}`);
        }
        loadMatakuliah(); // Refresh daftar
        alert('Mata Kuliah berhasil dihapus!');
    } catch (error) {
        console.error('Error deleting mata kuliah:', error);
        alert('Gagal menghapus mata kuliah: ' + error.message);
    }
}